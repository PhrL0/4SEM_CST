package br.com.aweb.pesquisa_satisfacao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PesquisaSatisfacaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
