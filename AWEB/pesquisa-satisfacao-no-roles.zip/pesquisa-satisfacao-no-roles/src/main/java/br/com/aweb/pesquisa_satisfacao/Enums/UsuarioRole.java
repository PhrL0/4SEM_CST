package br.com.aweb.pesquisa_satisfacao.Enums;

public enum UsuarioRole {
    ADMIN,
    PADRAO
}
