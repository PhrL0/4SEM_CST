package br.com.aweb.pesquisa_satisfacao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PesquisaSatisfacaoApplication {

	public static void main(String[] args) {
		SpringApplication.run(PesquisaSatisfacaoApplication.class, args);
	}

}
