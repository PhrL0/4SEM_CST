package com.manutencao.aweb.manutencao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManutencaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
